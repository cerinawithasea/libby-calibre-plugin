#
# Copyright (C) 2023 github.com/ping
#
# This file is part of the OverDrive Libby Plugin by ping
# OverDrive Libby Plugin for calibre / libby-calibre-plugin
#
# See https://github.com/ping/libby-calibre-plugin for more
# information
#
# Now being maintained at https://github.com/sgmoore/libby-calibre-plugin
#
from typing import Dict, Optional
from os.path import expanduser, isdir
from calibre.constants import DEBUG
from calibre.gui2 import Dispatcher, open_url , error_dialog
from calibre.gui2.dialogs.confirm_delete import confirm
from calibre.gui2.ebook_download import show_download_info
from calibre.gui2.threaded_jobs import ThreadedJob
from polyglot.builtins import as_unicode
from qt.core import (
    # QAbstractItemView,
    QCheckBox,
    QCursor,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMenu,
    QThread,
    QWidget,
    Qt,
)

from .base import BaseDialogMixin
from .widgets import DefaultQPushButton, DefaultQTableView
from ..compat import (
    QHeaderView_ResizeMode_ResizeToContents,
    QHeaderView_ResizeMode_Stretch,
    _c,
)
from ..config import PREFS, PreferenceKeys, PreferenceTexts, BorrowActions
from ..ebook_download import CustomEbookDownload
from ..libby import LibbyClient, LibbyFormats
from ..overdrive import OverDriveClient
from ..loan_actions import LibbyLoanRenew, LibbyLoanReturn
from ..magazine_download import CustomMagazineDownload
from ..models import (
    LibbyLoansModel,
    LibbyLoansSortFilterModel,
    get_media_title,
    truncate_for_display,
)

from ..utils import PluginImages
from ..workers import LibbyFulfillLoanWorker
from ..tools.CustomLogger import CustomLogger
from ..tools.decorators import enforce_types
from ..tools.error import Error

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..tools.lint_helper import load_translations
    from calibre.utils.localization import _, ngettext


load_translations()

gui_ebook_download = CustomEbookDownload()
gui_magazine_download = CustomMagazineDownload()

gui_libby_return = LibbyLoanReturn()
gui_renew_loan = LibbyLoanRenew()


class LoansDialogMixin(BaseDialogMixin):
    def __init__(self, *args):
        super().__init__(*args)
        self._readwithkindle_thread = QThread()

        widget = QWidget()
        widget.layout = QGridLayout()
        for col_num in range(1, self.view_hspan - 2):
            widget.layout.setColumnStretch(col_num, 1)
        widget.layout.setColumnMinimumWidth(0, self.min_button_width)
        widget.layout.setColumnMinimumWidth(self.view_hspan - 1, self.min_button_width)
        widget.setLayout(widget.layout)
        widget_row_pos = 0

        # Refresh button
        self.loans_refresh_btn = DefaultQPushButton(
            _c("Refresh"), self.resources[PluginImages.Refresh], self
        )
        self.loans_refresh_btn.setToolTip(_("Get latest loans"))
        self.loans_refresh_btn.clicked.connect(self.loans_refresh_btn_clicked)
        widget.layout.addWidget(self.loans_refresh_btn, widget_row_pos, 0)

        self.loans_filter_txt = QLineEdit(self)
        self.loans_filter_txt.setMinimumWidth(self.min_button_width)
        self.loans_filter_txt.setClearButtonEnabled(True)
        self.loans_filter_txt.setToolTip(_("Filter by Title, Author, Library"))
        self.loans_filter_txt.textChanged.connect(self.loans_filter_txt_textchanged)
        self.loans_filter_lbl = QLabel(_c("Filter"))
        self.loans_filter_lbl.setBuddy(self.loans_filter_txt)
        loan_filter_layout = QHBoxLayout()
        loan_filter_layout.addWidget(self.loans_filter_lbl)
        loan_filter_layout.addWidget(self.loans_filter_txt, 1)
        widget.layout.addLayout(
            loan_filter_layout, widget_row_pos, self.view_hspan - 2, 1, 2
        )
        widget_row_pos += 1

        self.loans_model = LibbyLoansModel(None, [], self.db, self.resources)
        self.loans_search_proxy_model = LibbyLoansSortFilterModel(
            self, model=self.loans_model, db=self.db
        )

        # The main loan list
        self.loans_view = DefaultQTableView(
            self, model=self.loans_search_proxy_model, min_width=self.min_view_width
        )

        horizontal_header = self.loans_view.horizontalHeader()
        for col_index in range(self.loans_model.columnCount()):
            horizontal_header.setSectionResizeMode(
                col_index,
                QHeaderView_ResizeMode_Stretch
                if col_index == 0
                else QHeaderView_ResizeMode_ResizeToContents,
            )
        # add context menu
        self.loans_view.customContextMenuRequested.connect(
            self.loans_view_context_menu_requested
        )
        # selection change
        self.loans_view.selectionModel().selectionChanged.connect(
            self.loans_view_selection_model_selectionchanged
        )
        # add debug trigger
        self.loans_view.doubleClicked.connect(
            lambda mi: self.display_debug("Loan", mi.data(Qt.UserRole))
            if DEBUG and mi.column() == self.loans_model.columnCount() - 1
            else self.show_book_details(mi.data(Qt.UserRole))
        )
        widget.layout.addWidget(
            self.loans_view, widget_row_pos, 0, self.view_vspan, self.view_hspan
        )
        widget_row_pos += self.view_vspan

        # Hide books already in lib checkbox
        self.hide_book_already_in_lib_checkbox = QCheckBox(
            PreferenceTexts.HIDE_BOOKS_ALREADY_IN_LIB, self
        )
        self.hide_book_already_in_lib_checkbox.setChecked(
            PREFS[PreferenceKeys.HIDE_BOOKS_ALREADY_IN_LIB]
        )
        self.hide_book_already_in_lib_checkbox.clicked.connect(
            self.hide_book_already_in_lib_checkbox_state_clicked
        )
        self.hide_book_already_in_lib_checkbox.stateChanged.connect(
            self.hide_book_already_in_lib_checkbox_state_changed
        )
        widget.layout.addWidget(
            self.hide_book_already_in_lib_checkbox, widget_row_pos, 0, 1, 2
        )

        # Create empty calibre book 
        self.empty_book_btn = DefaultQPushButton(
            ("Create empty entry in calibre"), None, self
        )
        self.empty_book_btn.setToolTip(_("Creates an empty entry in Calibre with the details of the loan"))
        self.empty_book_btn.clicked.connect(self.loans_empty_book_btn_clicked)
        widget.layout.addWidget(
            self.empty_book_btn,
            widget_row_pos,
            self.view_hspan - 2,
        )
       

        # Download button

        website = "overdrive.com" if PREFS[PreferenceKeys.PREFER_OVERDRIVE_WEBSITES] else "libbyapp.com"
        self.download_btn = DefaultQPushButton(
            _c(f"Open in {website}"), self.resources[PluginImages.Download], self
        )
        self.download_btn.setToolTip(_(f"Open loan in {website} website"))
        self.download_btn.clicked.connect(self.download_btn_clicked)
        widget.layout.addWidget(
            self.download_btn,
            widget_row_pos,
            self.view_hspan - 1,
        )
        widget_row_pos += 1

        self.loans_tab_index = self.add_tab(widget, _("Loans"))
        self.sync_starting.connect(self.base_sync_starting_loans)
        self.sync_ended.connect(self.base_sync_ended_loans)
        self.loan_added.connect(self.loan_added_loans)
        self.hold_added.connect(self.hold_added_loans)
        self.loan_removed.connect(self.loan_removed_loans)
        self.hold_removed.connect(self.hold_removed_loans)
        self.hide_title_already_in_lib_pref_changed.connect(
            self.hide_title_already_in_lib_pref_changed_loans
        )

    def loan_added_loans(self, loan: Dict):
        self.loans_model.add_loan(loan)

    def loan_removed_loans(self, loan: Dict):
        self.loans_model.remove_loan(loan)

    def hold_added_loans(self, hold: Dict):
        self.loans_model.add_hold(hold)

    def hold_removed_loans(self, hold: Dict):
        self.loans_model.remove_hold(hold)

    def base_sync_starting_loans(self):
        self.loans_refresh_btn.setEnabled(False)
        self.download_btn.setEnabled(False)
        self.loans_model.sync({})

    def base_sync_ended_loans(self, value):
        self.loans_refresh_btn.setEnabled(True)
        self.download_btn.setEnabled(True)
        self.loans_model.sync(value)

    def hide_title_already_in_lib_pref_changed_loans(self, checked):
        if self.hide_book_already_in_lib_checkbox.isChecked() != checked:
            self.hide_book_already_in_lib_checkbox.setChecked(checked)

    def hide_book_already_in_lib_checkbox_state_changed(self, __):
        checked = self.hide_book_already_in_lib_checkbox.isChecked()
        self.loans_search_proxy_model.set_filter_hide_books_already_in_library(checked)
        self.loans_view.sortByColumn(-1, Qt.AscendingOrder)

    def hide_book_already_in_lib_checkbox_state_clicked(self, checked):
        if PREFS[PreferenceKeys.HIDE_BOOKS_ALREADY_IN_LIB] != checked:
            PREFS[PreferenceKeys.HIDE_BOOKS_ALREADY_IN_LIB] = checked
            self.hide_title_already_in_lib_pref_changed.emit(checked)

    def loans_filter_txt_textchanged(self, text):
        self.loans_search_proxy_model.set_filter_text(text)

    def loans_refresh_btn_clicked(self):
        self.sync()

    def loans_view_selection_model_selectionchanged(self, selected, deselected):
        self.updateDownloadButtonText()
        selection_model = self.loans_view.selectionModel()
        if not selection_model.hasSelection():
            return
        indices = selection_model.selectedRows()
        loan = indices[-1].data(Qt.UserRole)
        status_bar_msg = get_media_title(loan)
        hold_count = loan.get("holdsCount", 0)
        owned_copies = loan.get("ownedCopies", 0)
        if loan.get("holdsCount") and not loan.get("availableCopies"):
            status_bar_msg += (
                " ("
                + ngettext(
                    "{n} copy in use.", "{n} copies in use.", owned_copies
                ).format(n=owned_copies)
                + " "
                + ngettext(
                    "{n} person waiting.", "{n} people waiting.", hold_count
                ).format(n=hold_count)
                + ")"
            )
        self.status_bar.showMessage(status_bar_msg, 3000)

    def updateDownloadButtonText(self) :
        # Default action is open in libbyapp   
        # this is the only action that works on multiple rows, otherwise the button is disabled.

        website = "overdrive.com" if PREFS[PreferenceKeys.PREFER_OVERDRIVE_WEBSITES] else "libbyapp.com"
     
        text = _c(f"Open in {website}")
        tooltip = _(f"Open loan in {website} website")
        selection_model = self.loans_view.selectionModel()

        self.download_btn.setEnabled(True)

        if selection_model.hasSelection():
            rows = selection_model.selectedRows()
            results = [self.getBorrowAction(row.data(Qt.UserRole)) for row in rows]

            borrow_action = results[0] 
            noOfResults = len(set(results))

            if noOfResults == 1 :
                if borrow_action == BorrowActions.BORROW_AND_DOWNLOAD :
                    text = _("Download")
                    tooltip = _("Download selected title")
            else :
                self.download_btn.setEnabled(False)

        self.download_btn.setText(text)
        self.download_btn.setToolTip(tooltip)                    

        return

    def loans_view_context_menu_requested(self, pos):
        selection_model = self.loans_view.selectionModel()
        if not selection_model.hasSelection():
            return
        indices = selection_model.selectedRows()
        menu = QMenu(self)
        menu.setToolTipsVisible(True)

        # add view in OverDrive/Libby menu actions
        self.add_view_in_menu_actions(menu, indices, self.loans_model)

        selected_loan = self.loans_view.indexAt(pos).data(Qt.UserRole)

        if PREFS[PreferenceKeys.INCL_NONDOWNLOADABLE_TITLES]:
            # Read with Kindle
            locked_in_format = LibbyClient.get_locked_in_format(selected_loan)
            if (locked_in_format == LibbyFormats.EBookKindle) or (
                # not yet locked into any format
                LibbyClient.has_format(selected_loan, LibbyFormats.EBookKindle)
                and not locked_in_format
            ):
                read_with_kindle_action = menu.addAction(
                    _('Read "{book}" with Kindle').format(
                        book=truncate_for_display(
                            get_media_title(selected_loan), font=menu.font()
                        )
                    )
                )
                read_with_kindle_action.setIcon(self.resources[PluginImages.Amazon])
                if (
                    LibbyClient.is_downloadable_ebook_loan(selected_loan)
                    and not locked_in_format
                ):
                    read_with_kindle_action.setToolTip(
                        "<p>"
                        + _(
                            "If you choose to Read with Kindle, this loan will be <u>format-locked</u> "
                            "and not downloadable."
                        )
                        + "</p>"
                    )
                read_with_kindle_action.triggered.connect(
                    lambda: self.read_with_kindle_action_triggered(
                        selected_loan, LibbyFormats.EBookKindle
                    )
                )

        if len(indices) == 1 : # These actions only work on one item, so disable them if more than one item is selected 
            
            # view book details
            self.add_view_book_details_menu_action(menu, selected_loan)
            # copy share link
            self.add_copy_share_link_menu_action(menu, selected_loan)
            # find calibre matches
            self.add_find_library_match_menu_action(menu, selected_loan)
            # search for title
            self.add_search_for_title_menu_action(menu, selected_loan)

        return_action = menu.addAction(
            ngettext("Return {n} loan", "Return {n} loans", len(indices)).format(
                n=len(indices)
            )
        )
        return_action.setIcon(self.resources[PluginImages.Return])
        return_action.triggered.connect(lambda: self.return_action_triggered(indices))

        if LibbyClient.is_renewable(selected_loan):
            if selected_loan.get("availableCopies") or not selected_loan.get(
                "holdsCount"
            ):
                renew_action = menu.addAction(
                    _('Renew "{book}"').format(book=get_media_title(selected_loan))
                )
                renew_action.setIcon(self.resources[PluginImages.Renew])
                renew_action.triggered.connect(
                    lambda: self.renew_action_triggered(selected_loan)
                )

            else:
                hold_action = menu.addAction(
                    _('Place hold on "{book}"').format(
                        book=get_media_title(selected_loan)
                    )
                )
                hold_action.setIcon(self.resources[PluginImages.Add])
                if not self.loans_model.has_hold(selected_loan):
                    hold_action.triggered.connect(
                        lambda: self.hold_action_triggered(selected_loan)
                    )
                else:
                    hold_action.setEnabled(False)
                    hold_action.setToolTip(_("An existing hold already exists."))

        menu.exec(QCursor.pos())

    def renew_action_triggered(self, loan):
        self.renew_loan(loan)

    def hold_action_triggered(self, loan):
        card = self.loans_model.get_card(loan["cardId"])
        self.create_hold(loan, card)

    def loans_empty_book_btn_clicked(self):
        self.empty_book_btn_clicked(self.downloaded_loan, self.loans_view.selectionModel(), self.loans_model)

    def download_btn_clicked(self):
        selection_model = self.loans_view.selectionModel()
        if selection_model.hasSelection():
            rows = selection_model.selectedRows()
            for row in reversed(rows):
                loan = row.data(Qt.UserRole)
                self.download_or_read_or_play_or_open(loan)

    def download_or_read_or_play_or_open(self, loan : Dict) :
        borrow_action   = self.getBorrowAction(loan)       
        format_id       = self.get_preferred_format(loan)
        self.download_or_read_or_play(loan)
        if borrow_action == BorrowActions.BORROW :
            self.open_fulfilment_website(loan, format_id)


    def download_or_read_or_play(self, loan : Dict) :
        borrow_action   = self.getBorrowAction(loan)        
        format_id       = self.get_preferred_format(loan)

        if borrow_action == BorrowActions.BORROW_AND_DOWNLOAD :
            self.download_loan(loan, format_id)
        elif borrow_action == BorrowActions.BORROW_AND_OPEN :
            self.open_fulfilment_website(loan, format_id)
        elif borrow_action == BorrowActions.BORROW :
            pass
        else :
            raise ValueError(f'Unexpected borrow_action {borrow_action}')
           

    def open_fulfilment_website(self, loan : Dict, format_id : Optional[str]) :
        url = self.get_loan_fulfilment_url(loan, format_id)
        
        CustomLogger.log_simple_string(f"Opening {url}")
        open_url(url)         

    def automatically_create_empty_book(self,  loan):
        try :
           self.create_empty_book(self.create_empty_book_callback, self.loans_model , loan)
        except Exception as e:
          CustomLogger.logger.exception(e)

    def create_empty_book_callback(self, job):
        if job.failed:
            try :
                CustomLogger.logger.exception(job.exception)
            except :  # noqa: E722
                pass
            self.unhandled_exception(job.exception, msg=_c("Failed to create calibre entry"))

        self.gui.status_bar.show_message(job.description + " " + _c("finished"), 5000)      

    def postBorrowAction(self, loan) :
        if PREFS[PreferenceKeys.AUTOMATICALLY_CREATE_ENTRY_IN_CALIBRE_AFTER_BORROWING] :
            borrow_action   = self.getBorrowAction(loan)  

            # If we are going to download the book, then that process will create a non-empty book
            # so there is no need to create an empty book. (Unless the download fails)
            if borrow_action != BorrowActions.BORROW_AND_DOWNLOAD :
                self.automatically_create_empty_book(loan)

        self.download_or_read_or_play(loan)

    def getBorrowAction(self, loan) :
        downloadable = LibbyClient.is_downloadable_ebook_loan(loan)

        return PREFS[PreferenceKeys.BORROW_ACTION_EBOOKS] if downloadable else PREFS[PreferenceKeys.BORROW_ACTION_OTHERS]

    def download_failed(self, loan : Dict) :
         if PREFS[PreferenceKeys.AUTOMATICALLY_CREATE_ENTRY_IN_CALIBRE_AFTER_BORROWING] :
            self.automatically_create_empty_book(loan)
  
    def download_loan(self, loan: Dict, format_id : Optional[str]):

        tags = self.get_calibre_tags(loan)

        error_message = None 
        if not format_id :
            error_message = 'Can not download loan as the no formats found'
            
        if not LibbyClient.is_format_downloadable(format_id) :
            error_message = f'Can not download loan as the selected format {format_id} is not downloadable '

        if not LibbyClient.is_downloadable_ebook_loan(loan):
            error_message = 'Only ebooks can be downloaded'

        if error_message :
            CustomLogger.log_simple_string(error_message)    
            error_dialog(self, "Can not download loan", error_message, show=True )
            self.download_failed(loan)
            return 

        show_download_info(get_media_title(loan), self)

        if not format_id :
            return 

        return self.download_ebook(
            loan,
            format_id,
            filename=f'{loan["id"]}.{LibbyClient.get_file_extension(format_id)}',
            tags=tags,
        )


    def download_ebook(self, loan: Dict, format_id: str, filename: str, tags=None):

        self.browser_assisted_download(loan, format_id)

        # if not tags:
        #     tags = []
        # card = self.loans_model.get_card(loan["cardId"])
        # library = self.loans_model.get_library(self.loans_model.get_website_id(card))

        # # We will handle the downloading of the files ourselves

        # book_id, mi = self.match_existing_book(loan, library, format_id)
        # if mi and book_id:
        #     CustomLogger.logger.debug("Matched existing empty book: %s", mi.title)

        # description = (
        #     _(
        #         "Downloading {format} for {book}".format(
        #             format=LibbyClient.get_file_extension(format_id).upper(),
        #             book=as_unicode(get_media_title(loan), errors="replace"),
        #         )
        #     )
        #     if book_id and mi
        #     else (
        #         _c("Downloading %s")
        #         % as_unicode(get_media_title(loan), errors="replace")
        #     )
        # )
        # callback = Dispatcher(self.downloaded_loan)
        # job = ThreadedJob(
        #     "overdrive_libby_download_book",
        #     description,
        #     gui_ebook_download,
        #     ( self.gui, self.client, loan, card, library, format_id, book_id, mi, filename, tags),
        #     {},
        #     callback,
        #     max_concurrent_count=1,
        #     killable=False,
        # )
        
        # self.gui.job_manager.run_threaded_job(job)
        # self.gui.status_bar.show_message(description, 3000)

    @enforce_types
    def get_loan_fulfilment_url(self, loan : Dict, format_id: Optional[str]) -> str :
        if PREFS[PreferenceKeys.PREFER_OVERDRIVE_WEBSITES] :
            card = self.loans_model.get_card(loan["cardId"])
            library = self.loans_model.get_library(self.loans_model.get_website_id(card))       
            library_key = library["preferredKey"]

            # Loans still say they support audiobook-mp3 format, but they don't any more
            # So we have to switch back to audiobook-overdrive (or loan["overDriveFormat"]["id"])
            if format_id == LibbyFormats.AudioBookMP3 :
                new_format = loan.get("overDriveFormat", None)
                if new_format :
                    new_format_id = new_format["id"]
                    if new_format_id != format_id :
                        CustomLogger.log_simple_string(f'get_loan_fulfilment_url uses format {new_format_id} rather than {format_id}')
                        format_id = new_format_id

            if format_id :
                return OverDriveClient.generate_download_ebook_permalink(library_key, format_id, loan["id"] )
            else :
                return OverDriveClient.library_title_permalink(library_key, loan["id"])
        else :
            return f'https://libbyapp.com/shelf/loans/{loan["cardId"]}-{loan["id"]}/fulfill'
            # What is the difference between this and LibbyClient.get_loan_fulfilment_details()
            # which returns something like f'https://sentry.libbyapp.com/card/{card_id}/loan/{loan_id}/fulfill/{format_id}'
            


    def browser_assisted_download(self, loan , format_id: str,):
        # do actual downloading of the loan

        Error.RaiseIfNot( format_id , "format_id must not be blank or None")

        CustomLogger.log_and_format(loan, "Attempted download")

        downloads_folder = PREFS.get(PreferenceKeys.DOWNLOADS_FOLDER, "")
        error_message = None
        details = None
        if not downloads_folder:
            error_message = _("Downloads Folder Not Set")
            details = _("Please configure your Downloads folder in the plugin settings (Loans tab) to use browser-assisted downloading.")
        else :        
            downloads_folder = expanduser(downloads_folder)
    
            if not isdir(downloads_folder) :
               error_message = _("Specified Downloads Folder does not exist")
               details = _("Please correct your Downloads folder in the plugin settings (Loans tab) to use browser-assisted downloading.")
        
        if error_message :
            error_dialog(self, error_message, details, show=True )
            self.open_fulfilment_website(loan, format_id)
            return
        


        Error.RaiseIfNot(downloads_folder , "downloads_folder must not be blank or None")

        from ..tools.WatchForFile import wait_for_file_qt
        
        expected_ext = "." + LibbyClient.get_file_extension(format_id) 
            
        url = self.get_loan_fulfilment_url(loan, format_id)
        CustomLogger.log_simple_string(f"Opening {url} and watching {downloads_folder} for {expected_ext}")
        open_url(url)

        from qt.core import QProgressDialog, Qt
        
        progress = QProgressDialog(_("Waiting for download to finish in browser..."), _("Cancel"), 0, 0, self)
        progress.setWindowTitle(_("Browser-Assisted Download"))
        progress.setWindowModality(Qt.WindowModal)
        progress.show()
        
        # Start watching
        file_path = wait_for_file_qt(downloads_folder, expected_ext, cancel_callback=progress.wasCanceled)
        progress.close()
        
        if file_path:
            CustomLogger.log_simple_string(f"File found at {file_path}, importing...")
            self.import_downloaded_file(loan, format_id, file_path)
        else:
            CustomLogger.log_simple_string("Download timed out or was canceled.")

    def import_downloaded_file(self, loan, format_id, file_path):
        
        tags = self.get_calibre_tags(loan)
        if LibbyClient.is_downloadable_magazine_loan(loan):
            downloader = CustomMagazineDownload()
        else:
            downloader = CustomEbookDownload()
            
        card = self.loans_model.get_card(loan["cardId"])
        library = self.loans_model.get_library(self.loans_model.get_website_id(card))

        book_id, metadata = self.match_existing_book(loan, library, format_id)
            
        description = _("Importing {format} for {book}").format(
            format=LibbyClient.get_file_extension(format_id).upper(),
            book=as_unicode(get_media_title(loan), errors="replace"),
        )
        
        callback = Dispatcher(self.downloaded_loan)
        
        job = ThreadedJob(
            "overdrive_libby_import",
            description,
            self._do_import_job,
            (downloader, self.gui, loan, card, library, format_id, file_path, book_id, tags, metadata),
            {},
            callback,
            max_concurrent_count=1,
            killable=False,
        )
        self.gui.job_manager.run_threaded_job(job)
        self.gui.status_bar.show_message(description, 3000)
      

    def _do_import_job(self, downloader, gui, loan, card, library, format_id, file_path, book_id, tags, metadata, log=None, abort=None, notifications=None):
        try:
            downloader.add(gui, loan, card, library, format_id, file_path, book_id, tags, metadata)
        finally:
            try:
                file_path.unlink(missing_ok=True)
            except Exception as e:
                CustomLogger.logger.warning(f"Could not remove temp file {file_path} : {e} ")
        return loan

    def download_magazine(self, loan: Dict, format_id: str, filename: str, tags=None):
        if not tags:
            tags = []
        card = self.loans_model.get_card(loan["cardId"])
        library = self.loans_model.get_library(self.loans_model.get_website_id(card))

        # We will handle the downloading of the files ourselves instead of depending
        # on the calibre browser

        # Heavily referenced from
        # https://github.com/kovidgoyal/calibre/blob/58c609fa7db3a8df59981c3bf73823fa1862c392/src/calibre/gui2/ebook_download.py#L127-L152

        book_id, mi = self.match_existing_book(loan, library, format_id)
        if mi and book_id:
            CustomLogger.logger.debug("Matched existing empty book: %s", mi.title)

        description = _c("Downloading %s") % as_unicode(
            get_media_title(loan), errors="replace"
        )

        callback = Dispatcher(self.downloaded_loan)
        job = ThreadedJob(
            "overdrive_libby_download_magazine",
            description,
            gui_magazine_download,
            (
                self.gui,
                self.client,
                self.overdrive_client,
                loan,
                card,
                library,
                format_id,
                book_id,
                mi,
                filename,
                tags,
            ),
            {},
            callback,
            max_concurrent_count=2,
            killable=True,
        )
        self.gui.job_manager.run_threaded_job(job)
        self.gui.status_bar.show_message(description, 3000)

    def return_action_triggered(self, indices):
        msg = (
            ngettext(
                "Return this loan?", "Return these {n} loans?", len(indices)
            ).format(n=len(indices))
            + "\n- "
            + "\n- ".join(
                [get_media_title(index.data(Qt.UserRole)) for index in indices]
            )
        )

        if confirm(
            msg,
            name=PreferenceKeys.CONFIRM_RETURNS,
            parent=self,
            title=_("Return Loans"),
            config_set=PREFS,
        ):
            for index in reversed(indices):
                loan = index.data(Qt.UserRole)
                self.return_loan(loan)

    def return_loan(self, loan: Dict):
        description = _("Returning {book}").format(
            book=as_unicode(get_media_title(loan), errors="replace")
        )
        callback = Dispatcher(self.returned_loan)
        job = ThreadedJob(
            "overdrive_libby_return",
            description,
            gui_libby_return,
            (self.gui, self.client, loan),
            {},
            callback,
            max_concurrent_count=2,
            killable=False,
        )
        self.gui.job_manager.run_threaded_job(job)
        self.gui.status_bar.show_message(description, 3000)

    def returned_loan(self, job):
        # callback after returning loan
        if job.failed:
            return self.unhandled_exception(
                job.exception, msg=_("Failed to return loan")
            )

        self.loan_removed.emit(job.result)
        self.gui.status_bar.show_message(job.description + " " + _c("finished"), 5000)

    def downloaded_loan(self, job):
        if job.failed:
            try :
                CustomLogger.logger.exception(job.exception)
            except :  # noqa: E722
                pass
            # self.gui.job_exception(job, dialog_title=_c("Failed to download e-book"))
            self.unhandled_exception(job.exception, msg=_c("Failed to download e-book"))

        try:
            if job.result:
                self.loans_search_proxy_model.unhide(job.result)
        except RuntimeError as runtime_err:
            # most likely because the plugin UI was closed before download was completed
            CustomLogger.logger.warning("Error displaying media results: %s", runtime_err)
        self.gui.status_bar.show_message(job.description + " " + _c("finished"), 5000)

    def read_with_kindle_action_triggered(self, loan: Dict, format_id: str):
        require_confirmation = LibbyClient.is_downloadable_ebook_loan(
            loan
        ) and not LibbyClient.get_locked_in_format(loan)

        if (not require_confirmation) or confirm(
            "<p>"
            + _(
                "If you choose to Read with Kindle, this loan will be <u>format-locked</u> "
                "and not downloadable."
            )
            + "</p></p>"
            + _("Do you wish to continue?")
            + "</p>",
            name=PreferenceKeys.CONFIRM_READ_WITH_KINDLE,
            parent=self,
            title=_("Read with Kindle"),
            config_set=PREFS,
        ):
            if not self._readwithkindle_thread.isRunning():
                self._readwithkindle_thread = self._get_readwithkindle_thread(
                    self.client, loan, format_id
                )
                self.setCursor(Qt.WaitCursor)
                self._readwithkindle_thread.start()

    def _get_readwithkindle_thread(self, libby_client, loan: Dict, format_id: str):
        thread = QThread()
        worker = LibbyFulfillLoanWorker()
        worker.setup(libby_client, loan, format_id)
        worker.moveToThread(thread)
        thread.worker = worker
        thread.started.connect(worker.run)

        def loaded(fulfilment_details):
            fulfilment_link = fulfilment_details.get("fulfill", {}).get("href")
            if fulfilment_link:
                open_url(fulfilment_link)
            self.unsetCursor()
            thread.quit()

        def errored_out(err: Exception):
            self.unsetCursor()
            thread.quit()
            raise err

        worker.finished.connect(lambda details: loaded(details))
        worker.errored.connect(lambda err: errored_out(err))

        return thread

    def renew_loan(self, loan):
        # create the hold
        description = _("Renewing loan on {book}").format(
            book=as_unicode(get_media_title(loan), errors="replace")
        )
        callback = Dispatcher(self.loan_renewed)
        job = ThreadedJob(
            "overdrive_libby_renew_loan",
            description,
            gui_renew_loan,
            (self.gui, self.client, loan),
            {},
            callback,
            max_concurrent_count=2,
            killable=False,
        )
        self.gui.job_manager.run_threaded_job(job)
        self.gui.status_bar.show_message(description, 3000)

    def loan_renewed(self, job):
        # callback after loan is renewed
        if job.failed:
            return self.unhandled_exception(
                job.exception, msg=_("Failed to renew loan")
            )

        updated_loan = job.result
        for r in range(self.loans_model.rowCount()):
            index = self.loans_model.index(r, 0)
            loan = index.data(Qt.UserRole)
            if (
                loan["id"] == updated_loan["id"]
                and loan["cardId"] == updated_loan["cardId"]
            ):
                self.loans_model.setData(index, updated_loan)
                break

        self.gui.status_bar.show_message(job.description + " " + _c("finished"), 5000)
